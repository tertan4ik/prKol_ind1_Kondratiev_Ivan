﻿using System;
using System.IO;
using System.Collections.Generic;

namespace algoritm_3_kond
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileput = "t.txt";
            Stack<char> charStack = new Stack<char>();
            using (StreamReader sr = new StreamReader(fileput))
            {
                string line;
                while((line=sr.ReadLine())!=null)
                {
                    foreach(char c in line)
                    {
                        charStack.Push(c);
                    }
                    while(charStack.Count>0)
                    {
                        Console.Write(charStack.Pop());
                    }
                    Console.WriteLine();
                }
                
            }
        }
    }
}
